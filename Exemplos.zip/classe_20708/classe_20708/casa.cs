﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classe_20708
{
   public class casa : moradia
    {
        public string tipo;

    }
}
