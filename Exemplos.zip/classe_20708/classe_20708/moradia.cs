﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classe_20708
{
    public class moradia
    {
        public string Localizacao;
        public string cor;
        public string referencia;
        public string tipo;

        public void alteracor(string cor)
        {
            Console.WriteLine("A minha casa é " + cor);
        }
        public void alterarefencia(string referencia)
        {
            Console.WriteLine("Nova Referencia: " + referencia);
        }
    }
}
