﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classe_20708
{
    public class apartamento : moradia
    {
        public int andar;
        public string bloco;

    public  string atrativos()
        {
            string mercado = "Mercadinho";
            return mercado;

        }
    }

}
