﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pessoa_POO
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Todo construtor deve possuir o mesmo nome da classe
            //estrutura da classe esta mais enxuta com os getters and setters automáticos. Observe que em vez de apenas um construtor temos dois.

            Pessoa p = new Pessoa();//UTILIZANDO CONSTRUTOR DEFAULT
            p.Nome = "Wilson Pereira";
            p.Bracos = 4;
            p.Pernas = 6;
            p.Olhos = 9;
            p.CorCabelo = "Castanho";
            Console.WriteLine(p.Nome + " possui " + p.Bracos +
            " braços," + "\n" + p.Pernas + " pernas, \n " + p.Olhos +
            " olhos e cabelo " + p.CorCabelo + "\n");

            Pessoa p1 = new Pessoa("Ruivo");
            //UTILIZANDO CONSTRUTOR PERSONALIZADO
            p1.Nome = "Sicrano";
            p1.Pernas = 60;

            Console.WriteLine(p1.Nome + " possui " + p1.Bracos +
            " braços" + ",\n" + p1.Pernas + " pernas, \n " + p1.Olhos +
            " olhos e cabelo " + p1.CorCabelo);

            Console.ReadKey();
        }
    }
}
