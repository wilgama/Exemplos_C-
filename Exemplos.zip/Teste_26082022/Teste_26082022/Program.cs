﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Teste_26082022
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] array = { 1, 4, 9 };
            Console.WriteLine("Antes do Método na posicao 0 = " + array[1]);

            posicaofor(array);
          //  posicaoforif(array);
          //  posicaowhile(array);
           // posicaoforeach(array);
           // perguntawhile(array);
            /*          
            /*          
                        if (array[1] == 9)
                        {
                            Console.WriteLine("Estou na posicao 3 e o valor é " + array[2]);
                        }
                        else
                        {
                            Console.WriteLine("Estou fora da posicação Desejada");
                        }
            */
           // mudar(ref array);
           // Console.WriteLine("Após do Método na posicao 0 = " + array[1]);

            Console.ReadLine();
        }

        static void mudar(ref int[] parray)
        {
            parray = new int[5] { 66, 10, 20, 30, 40 };
            Console.WriteLine("Dentro do método = " + parray[1]);

        }

        static void posicaofor(int[] parray)
        {
            // Percorre todo o array
              for (int i = 0; i < parray.Length; i++)
                Console.WriteLine($"voce esta na  posicao  {i} e o valor é = " + parray[i]);

        }
        static void posicaoforif(int[] parray)
        {
            int indice = -1;

            // Percorre todo o array
            for (int i = 0; i < parray.Length; i++)

            {
                // Verifica se o valor no índice 'i' é igual ao numero 4.
                if (parray[i] == 4)
                {
                    indice = i;
                    Console.WriteLine($"voce esta  no FOR_IF na  posicao  {i} e o valor é = " + parray[i]);
                    break; // Para o loop
                }
            }

        }
        static void posicaowhile(int[] parray)
        {
            // Percorre todo o array
            int i = 0;
            while (i < parray.Length)
            {
                Console.WriteLine($"voce esta no WHILE na  posicao  {i} e o valor é = " + parray[i]);
                i++;

            }

        }

        static void posicaoforeach(int[] parray)
        {
            // Percorre todo o array
            foreach (int x in parray)
            {
                Console.WriteLine($"voce esta no FOREACH e o valor é = " + x);
            }

        }

        static void perguntawhile(int[] parray)
        {
            // Percorre todo o array
            int i = 0;
            while (i < parray.Length)
            {
                Console.WriteLine("Quantas posicoes tem o array? (1, 2, 3)");
                i = Convert.ToInt16((Console.ReadLine()));

            }

        }
    }
}