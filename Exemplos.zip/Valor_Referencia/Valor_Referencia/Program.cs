﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Valor_Referencia
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int p1 = 10;
            string pessoa = "wilson";

            NovoNome novoNome = new NovoNome();
            novoNome.Pessoa = "Maria";
            
            Console.WriteLine(novoNome.Pessoa);
           // altera(novoNome);

            Console.WriteLine(novoNome.Pessoa);
            Console.ReadLine();
            
                    }
        public static void altera(NovoNome Pessoa2)
        {
            Pessoa2.Pessoa= "Jaqueline";
            Console.WriteLine(Pessoa2.Pessoa);

        }

        public class NovoNome {
            public string Pessoa { get; set; }
        }

    }

}
