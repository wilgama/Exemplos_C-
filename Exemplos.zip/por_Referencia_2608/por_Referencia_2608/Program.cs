﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Teste_26082022
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] array = { 1, 5, 9 };

            Console.WriteLine("Antes do Método = " + array[2]);
            
            if (array[1] == 4) {
                Console.WriteLine("o valor da posicao é = " + array[1]);
            } else
            {
                Console.WriteLine("O valor é diferente de 4");
            }

            mudar(ref array);
            Console.WriteLine("Após chamada do Método valor alterado para = " + array[2]);
            Console.ReadLine();
        }

        static void mudar(ref int[] parray)
        {
            parray = new int[5] { 66, 10, 20, 30, 40 };
            Console.WriteLine("Dentro do método = " + parray[2]);

        }

    }
}