﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes
{
   public class veiculo
    {
        public int numeroDeRodas;
        public string modelo;
        public int numerodePortas;
        public int velocidade = 0;
        public bool ligado = false;

        public void acelerar(int pvelocidade)
        {
            velocidade += pvelocidade;

            Console.WriteLine("velocidade" + velocidade + "km/h");

        }
        public void frear()
        {
            velocidade -= 10;
            if (velocidade < 10)
            {
                velocidade = 0;
            }
            Console.WriteLine("velocidade" + velocidade + "km/h");
        }
        public void ligar()
        {
            ligado = true;
        }
        public void desligar()
        {
            ligado = false;
        }
    }
}
