﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula_Classes
{
    public class moradia
    {
        public string localizacao;
        public string cor;
        public string refencia;
  

        public void alteracor(string cor)
        {
            Console.WriteLine("\nA cor da sua casa é = " + cor);
        }
        public void alterareferencia(string referencia)
        {
            Console.WriteLine("O ponto de referencia é: " + referencia);
        }
    }
}
