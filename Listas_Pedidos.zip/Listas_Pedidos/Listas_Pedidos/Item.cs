﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class Item
{
    private string _descricao;
    private decimal _quantidade;
    private decimal _subtotal;


    //Indexadores
    public string Descricao
    {
        get { return _descricao; }
        set { _descricao = value; }
    }

    public decimal Quantidade
    {
        get { return _quantidade; }
        set { _quantidade = value; }
    }

    public decimal Subtotal
    {
        get { return _subtotal; }
        set { _subtotal = value; }
    }

    public override string ToString()
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendLine("---");
        sb.AppendLine("Descrição: " + this._descricao);
        sb.AppendLine("Quantidade: " + this._quantidade.ToString("#,##0.00"));
        sb.AppendLine("Subtotal: " + this._subtotal.ToString("#,##0.00"));
        sb.AppendLine("---");
        return sb.ToString();
    }
}