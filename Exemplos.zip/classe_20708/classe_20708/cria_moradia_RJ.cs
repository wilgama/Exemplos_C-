﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classe_20708
{
    public class cria_moradia_RJ  : Imoradia
    {
        public moradia criarlocal()
        {
            return new moradia();

        }
        public moradia definirpraia()
        {
            return new moradia();

        }
        public moradia CriarMoradia(string tipo)
        {
            return new moradia()
            {
                tipo = "Apartamento"
            };
        }


    }
}
