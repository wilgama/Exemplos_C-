﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*var carro  = new Carro();
            carro.ligar();
            Console.WriteLine(carro.ligado);
            carro.acelerar(30);
            carro.acelerar(60);

            var carro2 = new Carro();
            carro2.acelerar(110);
            carro2.frear();  
            carro2.desligar();
            Console.WriteLine(carro2.ligado);

            var moto = new Carro();
            moto.acelerar(100);
            Console.WriteLine("A moto esta" + moto.ligado);

            carro2.portamalas = 200;*/

            //trabalho com interface

            Ifabrica ifabrica = new  fabricasp();
            var carro = ifabrica.criarveiculo("modelo");
            Console.WriteLine("O carro é do modelo: " + carro.modelo) ;

                Console.ReadLine();
            

        }
    }
}
