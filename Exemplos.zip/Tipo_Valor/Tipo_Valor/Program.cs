﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tipo_Valor
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int p1 = 10;
            Console.WriteLine(p1);
            mudanumero(p1);
            Console.WriteLine(p1);

            Console.ReadLine();
        }
        public static void mudanumero(int p1)
        {
            p1  = 20;
            Console.WriteLine(p1);
        }
    }

}
