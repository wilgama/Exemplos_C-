﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula_Classes
{
    public class apartamento : moradia
    {
        public int apto;
        public string bloco;
    }
}
