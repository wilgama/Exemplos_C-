﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tipo_Dados_Valor
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int p1 = 20;
            int p2 = p1++;
             Console.WriteLine("Neste ponto o parametro tem seu valor inicial = " + p1);
  
            MudaNumero(p1);
            Console.WriteLine("e agora ele vale = " + p1);
            Console.ReadLine();
        }
        public static void MudaNumero(int p2)
        {
            p2 = 30;
            
            Console.WriteLine(p2);

        }
    }
}
