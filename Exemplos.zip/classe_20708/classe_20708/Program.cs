﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classe_20708
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*casa casa = new casa();
            casa.Localizacao = "Rua Marinho, 2900";
            Console.WriteLine("A minha casa fica no endereço = " + casa.Localizacao);
            casa.alteracor("Azul");
            casa.alterarefencia("Carrefour");

            apartamento apartamento = new apartamento();
            apartamento.alteracor("Rosa");
            apartamento.andar = 15;
            apartamento.bloco = "Bloco 2";
            Console.WriteLine("Meu apartamento fica no andar =" + apartamento.andar + apartamento.bloco + "e tem o diferencial" 
                                                + apartamento.atrativos());

            casa casa3 = new casa();
            casa3.tipo = "Térrea";

            Console.WriteLine("Minha casa é do tipo:" + casa3.tipo);

            cria_moradia_SP cria_Moradia = new cria_moradia_SP();
            cria_Moradia.alteracor("verde");

            cria_moradia_RJ cria_Moradia_RJ = new cria_moradia_RJ();
            cria_Moradia_RJ.definirpraia();
            Console.WriteLine("Definir praia"+ cria_Moradia_RJ.definirpraia());*/

            Imoradia imoradia = new cria_moradia_RJ();
            var tipomoradia = imoradia.CriarMoradia("tipo");
            
            Console.WriteLine("Criar apenas:" + tipomoradia.tipo);


             Console.ReadLine();


        }
    }
}
