﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Polimorfismo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Polimorfismo em ação #1: um retângulo, um triângulo e um círculo
            // todos podem ser usados ​​onde quer que um Shape seja esperado. Nenhum elenco é
            // necessário porque existe uma conversão implícita de um derivado
            // classe para sua classe base.
            var shapes = new List<Shape>
{
    new Rectangle(),
    new Triangle(),
    new Circle()
    

        };

            // Polimorfismo no trabalho #2: o método virtual Draw é
            // invocado em cada uma das classes derivadas, não na classe base.
            foreach (var shape in shapes)
            {
                shape.Draw();

            }
            /* Resultado:
                            Desenhando um retângulo
                            Executando tarefas de desenho de classe base
                            Desenhando um triângulo
                            Executando tarefas de desenho de classe base
                            Desenhando um círculo
                            Executando tarefas de desenho de classe base
             */
            Console.ReadKey();

        }
    }
}
