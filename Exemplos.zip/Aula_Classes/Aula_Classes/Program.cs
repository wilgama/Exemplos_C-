﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula_Classes
{
    internal class Program
    {
        static void Main(string[] args)

        {
            casa casa = new casa();
            casa.localizacao = "Rua Virgulino, 2000 - CEP: 99999-0000";
            Console.Write("Minha casa fica em: " + casa.localizacao);
            casa.alteracor("azul");
            casa.alterareferencia(Console.ReadLine().ToUpper());
            casa.quintal = false;
            apartamento apartamento = new apartamento();
            apartamento.alteracor("verde");
            apartamento.apto = 12;
            apartamento.bloco = "B15";
            Console.WriteLine("Seu apartamento fica no" + apartamento.bloco +" - " +apartamento.apto);

            Console.ReadLine();

        }
    }
}
