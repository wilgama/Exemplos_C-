﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tipo_Referencia
{
    internal class Program
    {
        static void Main(string[] args)
        {
            NovaPessoa Novapessoa = new NovaPessoa();
            Novapessoa.Nome = "Maria";

            string pessoa = "Joelma";
            Console.WriteLine(pessoa);
            NovoMome(Novapessoa);
            Console.WriteLine(pessoa);
            Console.ReadLine();

        }
        public static void NovoMome(NovaPessoa pessoa)
        {
            pessoa.Nome = "Maria";
            Console.WriteLine(pessoa.Nome);
        }
        public class NovaPessoa {
            public string Nome { get; set; }
            
        }
    }
}
