﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pessoa_POO
{
    public class Pessoa
    {
        //construtor pesonalizado
        public Pessoa(string cabelo)//Valor obrigatório
        {
            //Atributos 
            Olhos = 2;//Valor default
            Bracos = 2;
            Pernas = 40;
            CorCabelo = cabelo;
            CorPele = "pardo";
        }
        public Pessoa()
        {
        }
        //construtores
        public string Nome { get; set; }
        public int Olhos { get; set; }
        public string CorCabelo { get; set; }
        public int Bracos { get; set; }
        public int Pernas { get; set; }

        public string CorPele { get; set;}

        // Métodos(Comportamento)
        public void Andar(int velocidade)
        {
            // Ande um pouco
        }
        public void Falar()
        {
            // Converse mais
        }
        public void Comer()
        {
            // alimente-se mais
        }
    }
}