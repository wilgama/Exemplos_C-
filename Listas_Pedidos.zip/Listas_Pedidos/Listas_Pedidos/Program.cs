﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Listas_Pedidos
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Pedido pedido = new Pedido();

                pedido.AdicionarItem(new Item()
                {
                    Descricao = "Monitor LCD 21''",
                    Quantidade = 1,
                    Subtotal = 400
                });

                pedido.AdicionarItem(new Item()
                {
                    Descricao = "Mouse Optico",
                    Quantidade = 2,
                    Subtotal = 98
                });

                pedido.AdicionarItem(new Item()
                {
                    Descricao = "Gabinete Gamer",
                    Quantidade = 1,
                    Subtotal = 750
                });

                pedido.AdicionarItem(new Item()
                {
                    Descricao = "Cadeira Gamer",
                    Quantidade = 1,
                    Subtotal = 2550
                });



                Console.WriteLine($"O pedido tem {pedido._registros} itens. Qual você deseja acessar?" );
                int indice = int.Parse(Console.ReadLine());
                Console.WriteLine(pedido[indice].ToString());
            }
            catch (Exception ex)
            {
                Console.WriteLine("ERRO: " + ex.Message);
            }
            Console.ReadLine();
        }
    }
}
