﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaNotas
{
    internal class Program
    {
        static void Main(string[] args)
        {
            using (var db = new GamaEntities())
            {
                /*
                 // Inserir Alunos
                Aluno aluno1 =  new Aluno()
                {
                   
                    Nome = "Mathias",
                    Email = "mathias@gama.com.br",
                    Celular = "12345-1234"
                    
                };
                // Gravar o registro
                db.Alunoes.Add(aluno1);
                // Commit 
                db.SaveChanges();

                Aluno aluno2 = new Aluno() { 
                    Nome = "Jurema2",
                    Email = "jurema2@gama.com.br",
                    Celular = "34444-99999"
          
                };
                // Gravar o registro
                db.Alunoes.Add(aluno2);
                // Commit 
                db.SaveChanges();

                // Inserir Notas
                aluno1.Notas.Add(new Nota
                {
                    Nota1 = 5,
                    Nota2  = 5,
                    Nota3 = 7,
                    Nota4 = 3

                });


                aluno2.Notas.Add(new Nota
                {
                    Nota1 = 6,
                    Nota2 = 9,
                    Nota3 = 2,
                    Nota4 = 3

                });
                //Committ das notas
                db.SaveChanges(); */
                // query para pesquisa
                var query = from c in db.Alunoes.Include("Notas")
                            select c;
                // select * from alunos
                // join notas on nota.id_Aluno = aluno.id_aluno

                //listar os registros
                foreach (var aluno in query)
                {
                    Console.WriteLine($"Aluno: {aluno.IdAluno} - {aluno.Nome} - e-mail: {aluno.Email} - celular: {aluno.Celular}");
                    Console.WriteLine("=========================================================================");
                    Console.WriteLine("===================================Veja suas Notas !!!!!!!!!!!!!!!!!!!!");
                    foreach (var n in aluno.Notas)
                    {
                        Console.WriteLine($"============== Nota 1 =  {n.Nota1} =================== ");
                        Console.WriteLine($"============== Nota 2 =  {n.Nota2} =================== ");
                        Console.WriteLine($"============== Nota 3 =  {n.Nota3} =================== ");
                        Console.WriteLine($"============== Nota 4 =  {n.Nota4} =================== ");
                        Console.WriteLine($"============== Média =  {((n.Nota1 + n.Nota2 + n.Nota3 + n.Nota4) / 4)} =================== ");

                    }
                }

                //atualizar
                var atualiza = db.Alunoes.SingleOrDefault(x => x.IdAluno == 2);
                // Select * from aluno where idaluno = 1

                if (atualiza != null)
                {
                    atualiza.Celular = "00000-1111";
                    db.SaveChanges();
                }

                //deletar 
                var ItemRemove = db.Notas.SingleOrDefault(x => x.IdAluno == 1);

                if (ItemRemove != null)
                {
                    db.Notas.Remove(ItemRemove);
                    db.SaveChanges();

                }
            }
            Console.WriteLine("Registro gravado!!!. Pressione qq tecla para continuar");
            Console.ReadKey();
 




        }

        private static IDisposable GamaEntities()
        {
            throw new NotImplementedException();
        }
    }
}
