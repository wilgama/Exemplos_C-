﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Pedido
{
    private List<Item> _itens;
    public int _registros = 0;

    public Pedido()
    {
        _itens = new List<Item>();
    }

    public void AdicionarItem(Item item)
    {
        this._itens.Add(item);
        _registros++;
    }

    public Item this[int indice]
    {
        get
        {
            if (indice < this._itens.Count)
                return this._itens[indice];
            else
                throw new IndexOutOfRangeException("O índice está fora dos limites.");
        }

        set
        {
            this._itens[indice] = value;
        }
    }
}
